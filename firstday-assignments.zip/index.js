// Print "Masai School" in the console followed by "A Transformation in Education" in next line
let name="Masai School";
console.log(name);
let name1="A Transformation in Education";
console.log(name1);