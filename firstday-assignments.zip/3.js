// Store the name, school, grade, section, rollno and the marks scored by the student in 3 subjects
// Print the report card of the student (You can make it look nice by using some keyboard symbols )
// Explore ASCII ART (https://en.wikipedia.org/wiki/ASCII_art (Links to an external site.)) or Text Art (https://fsymbols.com/text-art/ (Links to an external site.)) for some inspiration

console.log("******  REPORT CORD  ******");
console.log("Name    : Chandrakala");
console.log("School  : ZP girls high school");
console.log("Grade   : A");
console.log("Section : B");
console.log("Rollno  : 7");
console.log("Subjects: Telugu,English,Hindi");
let Telugu=91;
let English=80;
let Hindi=80;
console.log(Telugu,English,Hindi);
